package yantuck.yogaclass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YogaclassApplicationTests {

	@Test
	void contextLoads() {
	}

}
